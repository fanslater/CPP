// EditableListCtrlTestDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include ".\EditableListCtrl\EditableListCtrl.h"

// CEditableListCtrlTestDlg dialog
class CEditableListCtrlTestDlg : public CDialog
{
// Construction
public:
	CEditableListCtrlTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_EDITABLELISTCTRLTEST_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	friend void TestListCtrlItemUpdateAftFunc(CWnd* pParent, CEditableListCtrl *pEditableListCtrl, int iItem, int iSubItem);
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CEditableListCtrl m_listCtrl;
	afx_msg void OnLvnBeginScrollList1(NMHDR *pNMHDR, LRESULT *pResult);
};
