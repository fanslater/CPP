// EditableListCtrlTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EditableListCtrlTest.h"
#include "EditableListCtrlTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEditableListCtrlTestDlg dialog

CEditableListCtrlTestDlg::CEditableListCtrlTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditableListCtrlTestDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_listCtrl.SetItemUpdateAftCallBackFunc(TestListCtrlItemUpdateAftFunc);
}

void CEditableListCtrlTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_listCtrl);
}

void TestListCtrlItemUpdateAftFunc(CWnd* pParent, CEditableListCtrl *pEditableListCtrl, int iItem, int iSubItem)
{
	CEditableListCtrlTestDlg *pDlg = (CEditableListCtrlTestDlg*)pParent;
	if (pEditableListCtrl != &pDlg->m_listCtrl)
	{
		return;
	}
	if (iSubItem == 3)
	{
		CString cstrText = pEditableListCtrl->GetItemText(iItem, iSubItem);
		AfxMessageBox(cstrText);
	}

	return;
}

BEGIN_MESSAGE_MAP(CEditableListCtrlTestDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(LVN_BEGINSCROLL, IDC_LIST1, &CEditableListCtrlTestDlg::OnLvnBeginScrollList1)
END_MESSAGE_MAP()


// CEditableListCtrlTestDlg message handlers

BOOL CEditableListCtrlTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	// Style
	DWORD dwStyle = ::GetWindowLong(m_listCtrl.GetSafeHwnd(), GWL_STYLE); 
	dwStyle |= LVS_SINGLESEL;       //ֻ�ɵ���ѡ��
	dwStyle |= LVS_SHOWSELALWAYS;   //Always show selection
	::SetWindowLong(m_listCtrl.GetSafeHwnd(), GWL_STYLE, dwStyle);

	// Extended Style
	DWORD dwStyleEx = m_listCtrl.GetExtendedStyle();
	dwStyleEx |= LVS_EX_GRIDLINES;        //������
	dwStyleEx |= LVS_EX_FULLROWSELECT;    //���и���
	dwStyleEx |= LVS_EX_CHECKBOXES;       //Itemǰ����check box
	m_listCtrl.SetExtendedStyle(dwStyleEx);

	// ������
	m_listCtrl.InsertColumn(0, TEXT("Name"), LVCFMT_LEFT, 100);

	m_listCtrl.InsertColumn(1, TEXT("Age"), LVCFMT_LEFT, 60);
	m_listCtrl.SetColumnCtrlType(1, CCT_EDITBOX);

	m_listCtrl.InsertColumn(2, TEXT("Gender"), LVCFMT_LEFT, 80);
	m_listCtrl.SetColumnCtrlType(2, CCT_COMBOBOX);
	list<string> lstValue;
	lstValue.push_back("Male");
	lstValue.push_back("Female");
	m_listCtrl.SetColumnComboValue(2, lstValue);

	m_listCtrl.InsertColumn(3, TEXT("Test"), LVCFMT_LEFT, 80);
	m_listCtrl.SetColumnCtrlType(3, CCT_COMBOBOX);
	lstValue.clear();
	lstValue.push_back("12");
	lstValue.push_back("34");
	m_listCtrl.SetColumnComboValue(3, lstValue);

	// ������
	int nItem = 0;
	nItem = m_listCtrl.InsertItem(m_listCtrl.GetItemCount(), TEXT("WangYao"), 0);
	m_listCtrl.SetItemText(nItem, 1, TEXT("26"));   //�����1��ʼ,0��������
	m_listCtrl.SetItemText(nItem, 2, TEXT("Male"));
	m_listCtrl.SetItemText(nItem, 3, TEXT("12"));

	nItem = m_listCtrl.InsertItem(m_listCtrl.GetItemCount(), TEXT("WangYan"), 0);
	m_listCtrl.SetItemText(nItem, 1, TEXT("24"));
	m_listCtrl.SetItemText(nItem, 2, TEXT("Female"));
	m_listCtrl.SetItemText(nItem, 3, TEXT("12"));

	nItem = m_listCtrl.InsertItem(m_listCtrl.GetItemCount(), TEXT("WangXuan"), 0);
	m_listCtrl.SetItemText(nItem, 1, TEXT("24"));
	m_listCtrl.SetItemText(nItem, 2, TEXT("Female"));
	m_listCtrl.SetItemText(nItem, 3, TEXT("12"));

	nItem = m_listCtrl.InsertItem(m_listCtrl.GetItemCount(), TEXT("WangJiLiang"), 0);
	m_listCtrl.SetItemText(nItem, 1, TEXT("15"));
	m_listCtrl.SetItemText(nItem, 2, TEXT("Male"));
	m_listCtrl.SetItemText(nItem, 3, TEXT("12"));

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEditableListCtrlTestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEditableListCtrlTestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CEditableListCtrlTestDlg::OnLvnBeginScrollList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	// This feature requires Internet Explorer 5.5 or greater.
	// The symbol _WIN32_IE must be >= 0x0560.
	LPNMLVSCROLL pStateChanged = reinterpret_cast<LPNMLVSCROLL>(pNMHDR);
	// TODO: Add your control notification handler code here
	//AfxMessageBox(TEXT("123"));
	*pResult = 0;
}
